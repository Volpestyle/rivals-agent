"""Read only terminal confirmation volumes; never launch, fit, or overwrite."""
import hashlib
import json
from pathlib import Path
import sys
import time

ROOT = Path('/Users/james/dev/range-bc-data/explore/nitrogen-nohistory-confirm-20260927')
sys.path.insert(0, str(ROOT / 'candidate-s1'))
from encoder_lifecycle import connect
import modal

client = connect()
out = ROOT / 'evaluation-recovery'
out.mkdir(exist_ok=True)
for seed in (1, 2, 3):
    for arm in ('candidate', 'control'):
        name = f'{arm}-s{seed}'
        root = ROOT / name
        final_path = root / 'final.json'
        if not final_path.exists():
            print(name, 'STILL RUNNING; untouched', flush=True)
            continue
        final = json.loads(final_path.read_text())
        assert final['teardown']['terminal']
        dest = out / name
        if (dest / 'recovery-receipt.json').exists():
            print(name, 'already recovered', flush=True)
            continue
        dest.mkdir(exist_ok=False)
        config = json.loads((root / 'run-config.json').read_text())
        volume = modal.Volume.from_name(config['app_name'] + '-outputs')
        volume.hydrate(client=client)
        pins = json.loads((root / 'mount-pins.json').read_text())
        assert volume.object_id == pins['/outputs']
        receipt = {'arm': arm, 'seed': seed, 'volume': volume.object_id,
                   'original_final_sha256': hashlib.sha256(final_path.read_bytes()).hexdigest(),
                   'original_exit': final['exit'], 'original_terminal': True,
                   'recovered_at': time.time(), 'files': {},
                   'limitation': 'No pre-failure worker digest exists for epoch-26.pt; stable independent reads are checked.'}
        for name in ('epoch-26.pt', 'latest.pt', 'evaluation.json', 'status.json', 'run.log'):
            path = dest / name
            digest = hashlib.sha256()
            with path.open('xb') as f:
                for block in volume.read_file('/run/' + name):
                    digest.update(block)
                    f.write(block)
            info = {'bytes': path.stat().st_size, 'sha256': digest.hexdigest()}
            if name == 'epoch-26.pt':
                second = hashlib.sha256()
                for block in volume.read_file('/run/' + name):
                    second.update(block)
                assert second.hexdigest() == info['sha256']
                info['second_independent_read_sha256'] = second.hexdigest()
            receipt['files'][name] = info
        with (dest / 'recovery-receipt.json').open('x') as f:
            json.dump(receipt, f, indent=2)
        print(json.dumps(receipt), flush=True)
