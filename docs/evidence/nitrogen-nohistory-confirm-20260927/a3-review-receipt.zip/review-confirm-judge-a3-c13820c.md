# Confirm-judge A3 one-constant correction (c13820c): pre-result review

Reviewer: frame-review (Claude Opus 5.5; cross-family). 2026-09-27. Read-only; no metric value was read.

## Verdict: LAND. The corrected judge `confirm_encoder_judge_a3.py` (`66830ce6…6ef8c8`) is CLEARED for the confirmation judgement.

- **Exact delta.** A diff of `confirm_encoder_judge.py` against `confirm_encoder_judge_a3.py` at c13820c shows only
  line 20: `INPUT_SHA` loses its trailing `d` (65 → 64 hex characters). Every other byte is identical: decision
  rules, metrics and vocab pins, chance floor and receipt checks, which my earlier clearance of `6f2187dd` covered.
  The historical judge is unchanged at `6f2187dd…726aa32`.
- **Recomputed independently, on the Mac, read-only.**
  - `/Users/james/dev/range-bc-data/explore/modal15/manifest-modal.json` hashes to
    `aec08c08e247e3743ddeb1eec49dd880e1c0f62039c375932cab31dfccb91e22`.
  - `recipe.run_identity` in each of the six recovered `evaluation-recovery/*/epoch-26.pt` (candidate and control,
    seeds 1-3; all tagged CONFIRM with the right seed) is 128 characters. Its first 64 equal that hash, and none
    starts with the 65-character typo. I loaded only the recipe (`weights_only=True`); no `evaluation.json` was
    opened.
  - The committed `verified-model-input-manifest.json` is 1,487 bytes and hashes to the same value, and
    `judge-refusal.json` lists all six run identities with that 64-character prefix.
- **Pre-result record.** `preregistration-a3.md` (`fca0af0d…0d3d`) records the correction before any metric was
  inspected. It keeps the original preregistration and judge byte-intact, waives no identity check, and leaves every
  input, checkpoint, cutoff, rule, seed, condition and dependency pin as it was. `judge-refusal.json` holds hashes
  and identities only, no metric values.
- **Tests.** `test_confirm_encoder_judge_a3.py` and `test_confirm_encoder_judge.py`: 27/27 passed on my run, in an
  isolated `git archive c13820c`.

**Carried forward from the 5673de1 clearance (F1).** Whoever publishes the judgement must check its
`source_manifest`:
- `judge_sha256` = `66830ce6…`;
- metrics = `ff8ec178…` and vocab = `9f57c02a…`;
- the prereg set includes A3.
