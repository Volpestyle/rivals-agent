import json,os,subprocess,time
from pathlib import Path
R=Path('/Users/james/dev/range-bc-data/explore/nitrogen-nohistory-confirm-20260927')
assert (R/'mac-evaluation-a2b/judgement-a3.json').exists()
assert not (R/'cold-onsets').exists()
assert os.getpriority(os.PRIO_PROCESS,0)>=10
C=R/'mac-code-c13820c'
args=[str(R/'mac-eval-venv/bin/python'),'-u',str(C/'docs/evidence/nitrogen-nohistory-confirm-20260927/cold_onsets_a3.py')]
started=time.time()
with (R/'cold-onsets.log').open('x') as log:
 p=subprocess.Popen(args,cwd=C,env=dict(os.environ,OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',PYTHONDONTWRITEBYTECODE='1'),stdout=log,stderr=subprocess.STDOUT)
 with (R/'cold-onsets-launch.json').open('x') as f:json.dump({'pid':p.pid,'nice':os.getpriority(os.PRIO_PROCESS,p.pid),'command':args,'started_at':started,'metric_source_commit':'a8be454','runner_commit':'91dd14a'},f,indent=2)
 exit_code=p.wait()
with (R/'cold-onsets.exit').open('x') as f:f.write(str(exit_code)+'\n')
with (R/'cold-onsets-terminal.json').open('x') as f:json.dump({'pid':p.pid,'exit':exit_code,'terminal':True,'started_at':started,'checked_at':time.time()},f,indent=2)
