from pathlib import Path
import os,subprocess,json,time,hashlib,sys
R=Path('/Users/james/dev/range-bc-data/explore/nitrogen-nohistory-confirm-20260927')
C=R/'mac-replay-code-ec3a44f'
assert (R/'cold-onsets.exit').read_text().strip()=='0'
assert not (R/'offline-replay-parameterized').exists()
assert os.getpriority(os.PRIO_PROCESS,0)>=10
sys.path.insert(0,str(C))
from scripts.job_status import write
job='nitrogen-offline-replay-20260927'
args=[str(R/'mac-eval-venv/bin/python'),'-u','-m','policy.range_bc.offline_replay','--spec',str(R/'replay-spec.json'),'--out',str(R/'offline-replay-parameterized')]
started=time.time()
write(job,owner='explore-policy',host='mac',stage='running',progress='Pinned30s offline James/H1/NitroGen replay',evidence=str(R/'offline-replay.log'))
with (R/'offline-replay.log').open('x') as log:
 p=subprocess.Popen(args,cwd=C,env=dict(os.environ,OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',PYTHONDONTWRITEBYTECODE='1'),stdout=log,stderr=subprocess.STDOUT)
 with (R/'offline-replay-launch.json').open('x') as f:json.dump({'pid':p.pid,'started_at':started,'nice':os.getpriority(os.PRIO_PROCESS,p.pid),'command':args,'source_commit':'ec3a44f','spec_sha256':hashlib.sha256((R/'replay-spec.json').read_bytes()).hexdigest()},f,indent=2)
 exit_code=p.wait()
with (R/'offline-replay.exit').open('x') as f:f.write(str(exit_code)+'\n')
with (R/'offline-replay-terminal.json').open('x') as f:json.dump({'pid':p.pid,'terminal':True,'exit':exit_code,'started_at':started,'checked_at':time.time()},f,indent=2)
write(job,stage='done' if exit_code==0 else 'failed',progress='Offline replay complete' if exit_code==0 else 'Offline replay failed; see log')
