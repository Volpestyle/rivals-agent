"""Approved A2 Mac-only launch; no Modal SDK import or paid action."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

ROOT = Path('/Users/james/dev/range-bc-data/explore/nitrogen-nohistory-confirm-20260927')
CODE = ROOT / 'mac-code-88b231d'
OUT = ROOT / 'mac-evaluation-a2b'
assert not OUT.exists()
assert hashlib.sha256((ROOT / 'recovery-inputs.json').read_bytes()).hexdigest() == '14347004b5d12ed44a89d69961fcb2df7be8f1a34444460f145fee3c5797cf21'
assert hashlib.sha256((ROOT / 'recovery-inputs-control-s3.json').read_bytes()).hexdigest() == '05f6b4f7e135bd75cfeaa61fe0aa7aeb33b73e9cf2d6a575064d16bcd079702c'
assert shutil.disk_usage(ROOT).free > 10 * 1024**3
assert os.getpriority(os.PRIO_PROCESS, 0) >= 10
args = [str(ROOT / 'mac-eval-venv/bin/python'), '-u', '-m', 'policy.range_bc.confirm_encoder_recovery',
        '--inputs', str(ROOT / 'recovery-inputs.json'), '--out', str(OUT),
        '--manifest', str(ROOT.parent / 'manifest-full.json'),
        '--registry', str(CODE / 'data/human/session-splits.corpus.json'),
        '--tally', str(CODE / 'data/human/sessions/tally.json'),
        '--vision', str(ROOT.parent / 'encoder-historyoff-20260927/nitrogen/collected/assets/vision.safetensors'),
        '--vision-config', str(ROOT.parent / 'encoder-inference-handoff-20260927/config.json'),
        '--a2', str(CODE / 'docs/evidence/nitrogen-nohistory-confirm-20260927/preregistration-a2.md')]
args += ['--features-stage', str(ROOT / 'recovery-features-stage.json'), '--features-stage-sha256', 'd051df52812522d8973fec3b1e9a2dac5f1a37371cfdfd9798d553b53f66b23e', '--job-name', 'nitrogen-confirm-mac-evaluation-a2b']
assert hashlib.sha256((ROOT / 'recovery-features-stage.json').read_bytes()).hexdigest() == 'd051df52812522d8973fec3b1e9a2dac5f1a37371cfdfd9798d553b53f66b23e'
env = dict(os.environ, OMP_NUM_THREADS='2', MKL_NUM_THREADS='2', TOKENIZERS_PARALLELISM='false',
           PYTHONDONTWRITEBYTECODE='1')
started = time.time()
with (ROOT / 'mac-evaluation-a2b.log').open('x') as log:
    proc = subprocess.Popen(args, cwd=CODE, env=env, stdout=log, stderr=subprocess.STDOUT)
    with (ROOT / 'mac-evaluation-a2b-launch.json').open('x') as f:
        json.dump({'pid': proc.pid, 'launcher_pid': os.getpid(), 'started_at': started,
                   'nice': os.getpriority(os.PRIO_PROCESS, proc.pid), 'command': args,
                   'inputs_commit': '2975583', 'source_commit': '88b231d', 'cloud_spend': 0}, f, indent=2)
    code = proc.wait()
with (ROOT / 'mac-evaluation-a2b.exit').open('x') as f:
    f.write(str(code) + '\n')
with (ROOT / 'mac-evaluation-a2b-terminal.json').open('x') as f:
    json.dump({'pid': proc.pid, 'exit': code, 'terminal': True, 'started_at': started,
               'checked_at': time.time(), 'evidence': 'subprocess.wait returned; local process exited'}, f, indent=2)
