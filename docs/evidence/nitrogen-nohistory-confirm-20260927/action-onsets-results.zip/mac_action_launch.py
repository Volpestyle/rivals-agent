import json,os,subprocess,time
from pathlib import Path
R=Path('/Users/james/dev/range-bc-data/explore/nitrogen-nohistory-confirm-20260927')
assert (R/'mac-evaluation-a2b/judgement-a3.json').exists()
assert not (R/'action-onsets').exists()
assert (R/'offline-replay.exit').read_text().strip()=='0'
assert os.getpriority(os.PRIO_PROCESS,0)>=10
C=R/'mac-action-code-e466963'
args=[str(R/'mac-eval-venv/bin/python'),'-u',str(C/'docs/evidence/nitrogen-nohistory-confirm-20260927/action_onsets.py')]
started=time.time()
with (R/'action-onsets.log').open('x') as log:
 p=subprocess.Popen(args,cwd=C,env=dict(os.environ,OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',PYTHONDONTWRITEBYTECODE='1'),stdout=log,stderr=subprocess.STDOUT)
 with (R/'action-onsets-launch.json').open('x') as f:json.dump({'pid':p.pid,'nice':os.getpriority(os.PRIO_PROCESS,p.pid),'command':args,'started_at':started,'source_commit':'e466963'},f,indent=2)
 exit_code=p.wait()
with (R/'action-onsets.exit').open('x') as f:f.write(str(exit_code)+'\n')
with (R/'action-onsets-terminal.json').open('x') as f:json.dump({'pid':p.pid,'exit':exit_code,'terminal':True,'started_at':started,'checked_at':time.time()},f,indent=2)
